<?php

class BC_Cat_Widget extends WP_Widget
{

    /**
     * Imposta il nome del widget
     */
    public function __construct() {
        $widget_ops = array(
            'classname' => 'bc_current_cat',
            'description' => 'Show current post under category',
        );
        parent::__construct( 'bc_current_cat', 'Categoria dei post', $widget_ops );
    }


    function bc_cat_extract_cat_id($cat)
    {
        return $cat->term_id;
    }
    /**
     * Outputs del contenuto del widget
     *
     * @param array $args
     * @param array $instance
     */
    public function widget( $args, $instance ) {
        // outputs del contenuto del widget
        $cat_ids = get_the_category();
        $current_post_id = get_the_ID();
        if (count($cat_ids) == 0)
            return;


        $id_nums = array_map(array($this, 'bc_cat_extract_cat_id'), $cat_ids);

        $post_count = $instance['bc_cat_post_count'];
        $show_thumbnail = $instance['bc_cat_show_thumbnail'];
        $display_date = $instance['bc_cat_display_date'];
        $order_by = $instance['bc_cat_order_by'];



        $order_type = $instance['bc_cat_order_type'];
        $skip_current_post = $instance['bc_cat_skip_current_post'];


        $posts = (new WP_Query(array(
            'category__in' => $id_nums,
            'orderby' => $order_by,
            'order' => $order_type,
            'posts_per_page' => $post_count,
            'suppress_filters' => true

//            'posts_per_page' => $post_count
        )))->posts;

        $html = '';
        foreach ($posts as $post)
        {
            //toglie il post attuale
            if ($skip_current_post && ($post->ID == $current_post_id))
                continue;

            $html .= $this->single_post_html($post, array(
                    'show_thumbnail' => $show_thumbnail,
                    'display_date' => $display_date
            ));
        }


        echo "<ul class='bc-cat-widget-post-list'>".$html."</ul>";


    }

    /**
     * @param $post WP_Post
     * @param $show_thumbnail
     * @return string
     */
    private function single_post_html($post, $options)
    {
        $show_thumbnail = $options['show_thumbnail'];
        $display_date = $options['display_date'];
        $post_thumbnail = $show_thumbnail? "<span class='bc-cat-widget-thumbnail'>". get_the_post_thumbnail($post->ID, "thumbnail") . "</span>" : '';

        $post_title = "<span class='bc-cat-widget-title'>".$post->post_title."</span>";


        $date_string = $display_date ? "<span class='bc-cat-widget-date'>".date('M d, Y', strtotime($post->post_date))."</span>" : "";
//        $date_string = $display_date ? "<span class='bc-cat-widget-date'>".($post->post_date)."</span>" : "";


        $html = "<div class='bc-cat-image-and-title'>".
                    $post_thumbnail.$post_title.
                "</div>" .
                "<div class='bc-cat-post-date'>".
                    $date_string.
                "</div>"
        ;






        return "<a href='".get_post_permalink($post->ID)."'><li class='bc-cat-widget-single-post'>". $html . "</li></a>";


    }

    /**
     * Outputs opzioni Admin
     *
     * @param array $instance Per le opzioni del widget
     */
    public function form( $instance ) {
        // outputs the options form on admin
        $post_count = isset($instance['bc_cat_post_count']) ? $instance['bc_cat_post_count'] : 0;
        $order_by = isset($instance['bc_cat_order_by']) ? $instance['bc_cat_order_by'] : 0;
        $order_type = isset($instance['bc_cat_order_type']) ? $instance['bc_cat_order_type'] : 0;
        $show_thumbnail = isset($instance['bc_cat_show_thumbnail']) && intval($instance['bc_cat_show_thumbnail']) == 1 ? true : false;
        $display_date = isset($instance['bc_cat_display_date']) && intval($instance['bc_cat_display_date']) == 1 ? true : false;
        $skip_current_post = isset($instance['bc_cat_skip_current_post']) && intval($instance['bc_cat_skip_current_post']) == 1 ? true : false;

        ?>
        <div><label for="">Numero di post da mostrare?</label></div>
        <input type="number" id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_post_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_post_count' ) ); ?>"  value="<?php echo $post_count ?>">

        <div><label for="">Mostrare immagine?</label></div>
        <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_show_thumbnail' ) ); ?>" <?php echo (($show_thumbnail) ? 'checked' : ''); ?>  name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_show_thumbnail' ) ); ?>" >


        <div><label for="">Togliere il post attuale dalla lista?</label></div>
        <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_skip_current_post' ) ); ?>" <?php echo (($skip_current_post) ? 'checked' : ''); ?>  name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_skip_current_post' ) ); ?>" >


        <div><label for="">Mostra la data?</label></div>
        <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_display_date' ) ); ?>" <?php echo (($display_date) ? 'checked' : ''); ?>  name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_display_date' ) ); ?>" >

        <div><label for="">Ordina i post per</label></div>
        <select id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_order_by' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_order_by' ) ); ?>" >
            <option <?php echo ($order_by == "name") ? "selected" : "" ?> value="name">Titolo</option>
            <option <?php echo ($order_by == "date") ? "selected" : "" ?> value="date">Data pubblicazione</option>
            <option <?php echo ($order_by == "random") ? "selected" : "" ?> value="random">Ordine casuale</option>
        </select>


        <div><label for="">Asc/Disc</label></div>
        <select id="<?php echo esc_attr( $this->get_field_id( 'bc_cat_order_type' ) ); ?>"  name="<?php echo esc_attr( $this->get_field_name( 'bc_cat_order_type' ) ); ?>" >
            <option <?php echo ($order_type == "ASC") ? "selected" : "" ?>  value="ASC">Ascendente</option>
            <option <?php echo ($order_type == "DESC") ? "selected" : "" ?>  value="DESC">Discendente</option>
        </select>






    <?php

    }

    /**
     * Processa le opzioni del widget al salvataggio
     *
     * @param array $new_instance Per le nuove opzioni
     * @param array $old_instance Per le opzioni precedenti
     *
     * @return array
     */
    public function update( $new_instance, $old_instance ) {
        // le opzioni widget da salvare
        $instance = array();

        $instance['bc_cat_post_count'] = ( ! empty( $new_instance['bc_cat_post_count'] ) ) ? sanitize_text_field( $new_instance['bc_cat_post_count'] ) : '';
        $instance['bc_cat_order_by'] = ( ! empty( $new_instance['bc_cat_order_by'] ) ) ? sanitize_text_field( $new_instance['bc_cat_order_by'] ) : '';
        $instance['bc_cat_order_type'] = ( ! empty( $new_instance['bc_cat_order_type'] ) ) ? sanitize_text_field( $new_instance['bc_cat_order_type'] ) : '';
        $instance['bc_cat_show_thumbnail'] = ( ! empty( $new_instance['bc_cat_show_thumbnail'] ) ) ? 1 : 0;
        $instance['bc_cat_display_date'] = ( ! empty( $new_instance['bc_cat_display_date'] ) ) ? 1 : 0;
        $instance['bc_cat_skip_current_post'] = ( ! empty( $new_instance['bc_cat_skip_current_post'] ) ) ? 1 : 0;

        return $instance;
    }
}