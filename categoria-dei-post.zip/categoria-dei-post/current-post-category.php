<?php
/*
	Plugin Name: Categoria dei post
	Plugin URI: https://jacopokahl.com
	Description: Crea un widget che mostra gli articoli con la stessa categoria nella pagina del singolo post.
	Author: JacopoKahl
	Version: 1.0.0
	Author URI: https://jacopokahl.com
	Text Domain: categoria-dei-post
*/


include_once 'BC_Cat_Widget.php';


function bc_current_category_register_widget() {
    register_widget( 'BC_Cat_Widget' );
}

add_action( 'widgets_init', 'bc_current_category_register_widget' );



add_action('wp_enqueue_scripts', 'bc_uic_load_frontend_scripts', 1000);

function bc_uic_load_frontend_scripts()
{
    wp_register_style('bc-cat-widget-frontend-bundle-style', plugins_url( 'bundle/css/bc-cat-widget-front.css', __FILE__ ));
    wp_enqueue_style('bc-cat-widget-frontend-bundle-style');


}